package com.test;

public class Active {
    @Override
    public String toString () {
        return new String ("\n Hello from demo-api");
    }
}
